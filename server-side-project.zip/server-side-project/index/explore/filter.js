document.addEventListener('DOMContentLoaded', function () {
    const moodButtons = document.querySelectorAll('.intro button');
    const cards = document.querySelectorAll('.places-grid .card');
    const categorySelect = document.getElementById('category-select');
    const priceSelect = document.getElementById('price-select');
    const locationSelect = document.getElementById('location-select');

    let currentMood = 'all';

    // Handle Mood Button Clicks
    moodButtons.forEach(button => {
        button.addEventListener('click', function () {
            currentMood = this.textContent.trim().toLowerCase();
            filterCards();
        });
    });
// Toggle Favorite Heart Button
    const heartButtons = document.querySelectorAll('.heart-btn');

    heartButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            // Prevent the click from triggering anything behind the button
            e.stopPropagation();

            // Toggle between empty and filled heart
            if (this.textContent.trim() === '🤍') {
                this.textContent = '❤️';
            } else {
                this.textContent = '🤍';
            }
        });
    });
    // Handle Dropdown Changes
    if (categorySelect) categorySelect.addEventListener('change', filterCards);
    if (priceSelect) priceSelect.addEventListener('change', filterCards);
    if (locationSelect) locationSelect.addEventListener('change', filterCards);

    // Master Filtering Function
    function filterCards() {
        const selectedCategory = categorySelect ? categorySelect.value.toLowerCase() : 'all';
        const selectedPrice = priceSelect ? priceSelect.value.toLowerCase() : 'any';
        const selectedLocation = locationSelect ? locationSelect.value.toLowerCase() : 'all';

        cards.forEach(card => {
            let moodMatches = false;

            // 1. Check Mood Filter
            if (currentMood === 'all') {
                moodMatches = true;
            } else {
                const tags = card.querySelectorAll('.mini-tag');
                tags.forEach(tag => {
                    if (tag.textContent.trim().toLowerCase() === currentMood) {
                        moodMatches = true;
                    }
                });
            }

            // Note: To make Category/Price/Location fully functional with your cards, 
            // you can add matching data attributes to your HTML cards 
            // (e.g., data-category="cafe" data-price="free" data-location="khobar")
            let categoryMatches = (selectedCategory === 'all' || card.dataset.category === selectedCategory);
            let priceMatches = (selectedPrice === 'any' || card.dataset.price === selectedPrice);
            let locationMatches = (selectedLocation === 'all' || card.dataset.location === selectedLocation);

            // Show card only if all active filters match
            if (moodMatches && categoryMatches && priceMatches && locationMatches) {
                card.style.display = 'flex';
            } else {
                card.style.display = 'none';
            }
        });
    }
});